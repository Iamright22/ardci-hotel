<div class="menu-categories-body">
<div class="main-color-overlay color-overlay-sub-page"></div>
<div class="bg-menu-overlay bg-menu-overlay-sub-page"></div>


    <!-- home-Logo -->
    <!-- <div class="navi-home-div">
        <a href="../index.php" class="navi-home-a">
            <i class="fa-solid fa-house"></i>
        </a>
    </div> -->

    <!-- order list -->
    <div class="order-list-con" style="top:2.1rem;" id="orderListTop">
        <a href="listed-order.php" class="order-list-icon-a">
            <i class="fa-solid fa-clipboard-list"></i><span id="order-list-count">0</span>
        </a>
    </div>

    <!-- header navigation -->
    <div class="navigation-container">
        <!-- <div class="navigation-title"><h1 class="evs-title-sub eves-white">Eve's Menu</h1></div> -->
        <div class="log-sub-pages"><img src="../image/eves-logo.png" alt="logo here"></div>
    </div>

    <!-- cards categories -->
    <div class="menu-categories-container">