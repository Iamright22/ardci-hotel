<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width">
    <title>Eve's Blends & Spices Menu</title>

    <!-- tab icon -->
    <link rel="icon" href="../image/eves-log-tab.png">

    <!-- css -->
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">

    <!-- font awesome -->
    <link rel="stylesheet" href="../fontawesome-free-6.4.0-web/css/all.css">
</head>
<body>