<?php include 'includes-pages/header.php' ?>
<?php include 'includes-pages/menu-navigation.php' ?>

        <!-- frappesr title -->
        <div class="category-main-title">
            <h2 class="catg-title">Frappes</h2>
        </div>
        <div class="row">

            <!--Berry Velvet card -->
            <a role="button" class="cards-anchor col-6">
                <div class="menu-categories-card-container flex-grow-1">
                    <div class="mcc-ing-preview">
                        <div class="mcc-tilte-head">
                            <h1 class="mcc-title">Berry Velvet</h1>
                        </div>
                        <div class="mcc-ing">
                            <p class="">
                                Strawberry syrup, milk, and crushed ice topped with whipped cream.
                            </p>
                            <span class="in-prices">Price: &#8369;190.00</span>
                        </div>
                        <div class="add-list-con"><button class="add-list-btn" data-name='Berry Velvet' onclick="frappesArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                    </div>
                </div>
            </a>

            <!-- Javalicious card -->
            <a role="button" class="cards-anchor col-6">
                <div class="menu-categories-card-container mccc-right flex-grow-1">
                    <div class="mcc-ing-preview">
                        <div class="mcc-tilte-head">
                            <h1 class="mcc-title">Javalicious</h1>
                        </div>
                        <div class="mcc-ing">
                            <p class="">
                                Java chips, choco, milk, crushed ice, topped with whipped cream.
                            </p>
                            <span class="in-prices">Price: &#8369;175.00</span>
                        </div>
                        <div class="add-list-con"><button class="add-list-btn" data-name='Javalicious' onclick="frappesArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                    </div>
                </div>
            </a>

            <!-- Crusty Crunch card -->
            <a role="button" class="cards-anchor col-6">
                <div class="menu-categories-card-container flex-grow-1">
                    <div class="mcc-ing-preview">
                        <div class="mcc-tilte-head">
                            <h1 class="mcc-title">Crusty Crunch</h1>
                        </div>
                        <div class="mcc-ing">
                            <p class="crusty-crunch">
                                Oreo cookies blended with milk, crushed ice, topped with whipped cream and crushed oreo.
                            </p>
                            <span class="in-prices">Price: &#8369;145.00</span>
                        </div>
                        <div class="add-list-con"><button class="add-list-btn" data-name='Crusty Crunch' onclick="frappesArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                    </div>
                </div>
            </a>

            <!-- Strawberry Cucumber card -->
            <a role="button" class="cards-anchor col-6">
                <div class="menu-categories-card-container mccc-right flex-grow-1">
                    <div class="mcc-ing-preview">
                        <div class="mcc-tilte-head">
                            <h1 class="mcc-title">Strawberry Cucumber</h1>
                        </div>
                        <div class="mcc-ing">
                            <p class="">
                                Strawberry syrup and cucumber slices blended with milk, crushed ice and topped with whipped cream.
                            </p>
                            <span class="in-prices">Price: &#8369;125.00</span>
                        </div>
                        <div class="add-list-con"><button class="add-list-btn" data-name='Strawberry Cucumber' onclick="frappesArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                    </div>
                </div>
            </a>

            <!-- Choco Loco card -->
            <a role="button" class="cards-anchor col-6">
                <div class="menu-categories-card-container flex-grow-1">
                    <div class="mcc-ing-preview">
                        <div class="mcc-tilte-head">
                            <h1 class="mcc-title">Choco Loco</h1>
                        </div>
                        <div class="mcc-ing">
                            <p class="">
                                White choco powder and dark chocolate syrup blended with milk, crushed ice and topped with whipped cream.
                            </p>
                            <span class="in-prices">Price: &#8369;230.00</span>
                        </div>
                        <div class="add-list-con"><button class="add-list-btn" data-name='Choco Loco' onclick="frappesArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                    </div>
                </div>
            </a>

            <!-- Oh! Green Tea card -->
            <a role="button" class="cards-anchor col-6">
                <div class="menu-categories-card-container mccc-right flex-grow-1">
                    <div class="mcc-ing-preview">
                        <div class="mcc-tilte-head">
                            <h1 class="mcc-title">Oh! Green Tea</h1>
                        </div>
                        <div class="mcc-ing">
                            <p class="oh-green-tea-p">
                                Matcha green tea powder, blended with milk, crushed ice and topped with whipped cream.
                            </p>
                            <span class="in-prices">Price: &#8369;155.00</span>
                        </div>
                        <div class="add-list-con"><button class="add-list-btn" data-name='Oh! Green Tea' onclick="frappesArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                    </div>
                </div>
            </a>

             <!-- Java Peppermint card -->
            <a role="button" class="cards-anchor col-6">
                <div class="menu-categories-card-container flex-grow-1">
                    <div class="mcc-ing-preview">
                        <div class="mcc-tilte-head">
                            <h1 class="mcc-title">Java Peppermint</h1>
                        </div>
                        <div class="mcc-ing">
                            <p class="">
                                Java chip powder, peppermint syrup blended with milk, crushed ice and topped with whipped cream.
                            </p>
                            <span class="in-prices">Price: &#8369;220.00</span>
                        </div>
                        <div class="add-list-con"><button class="add-list-btn" data-name='Java Peppermint' onclick="frappesArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                    </div>
                </div>
            </a>

            <!-- Oreo Espresso Mocha card -->
            <a role="button" class="cards-anchor col-6">
                <div class="menu-categories-card-container mccc-right flex-grow-1">
                    <div class="mcc-ing-preview">
                        <div class="mcc-tilte-head">
                            <h1 class="mcc-title">Oreo Espresso Mocha</h1>
                        </div>
                        <div class="mcc-ing">
                            <p class="oreo-espressoM-p">
                                Espresso and oreo cookies blended with milk, crushed ice and topped with whipped cream.
                            </p>
                            <span class="in-prices">Price: &#8369;200.00</span>
                        </div>
                        <div class="add-list-con"><button class="add-list-btn" data-name='Oreo Espresso Mocha' onclick="frappesArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                    </div>
                </div>
            </a>

            <!-- Vanilla Sky card -->
            <a role="button" class="cards-anchor col-6">
                <div class="menu-categories-card-container flex-grow-1">
                    <div class="mcc-ing-preview">
                        <div class="mcc-tilte-head">
                            <h1 class="mcc-title">Vanilla Sky</h1>
                        </div>
                        <div class="mcc-ing">
                            <p class="vanilla-sky-p">
                                Espresso and vanilla powder blended with milk, crushed ice.
                            </p>
                            <span class="in-prices">Price: &#8369;145.00</span>
                        </div>
                        <div class="add-list-con"><button class="add-list-btn" data-name='Vanilla Sky' onclick="frappesArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                    </div>
                </div>
            </a>

            <!-- Vanilla Matcha -->
            <a role="button" class="cards-anchor col-6">
                <div class="menu-categories-card-container mccc-right flex-grow-1">
                    <div class="mcc-ing-preview">
                        <div class="mcc-tilte-head">
                            <h1 class="mcc-title">Vanilla Matcha</h1>
                        </div>
                        <div class="mcc-ing">
                            <p class="">
                                Vanilla syrup and matcha powder blended with milk, crushed ice, topped with whipped cream.
                            </p>
                            <span class="in-prices">Price: &#8369;220.00</span>
                        </div>
                        <div class="add-list-con"><button class="add-list-btn" data-name='Vanilla Matcha' onclick="frappesArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                    </div>
                </div>
            </a>

            <!-- Vanilla Strawberry card -->
                <a role="button" class="cards-anchor col-6">
                    <div class="menu-categories-card-container flex-grow-1">
                        <div class="mcc-ing-preview">
                            <div class="mcc-tilte-head">
                                <h1 class="mcc-title">Vanilla Strawberry</h1>
                            </div>
                            <div class="mcc-ing">
                                <p class="">
                                    Vanilla powder and strawberry syrup blended with vanilla ice cream, milk, crushed ice, topped with whipped cream.
                                </p>
                                <span class="in-prices">Price: &#8369;190.00</span>
                            </div>
                            <div class="add-list-con"><button class="add-list-btn" data-name='Vanilla Strawberry' onclick="frappesArray(this)"><i class="fa-solid fa-clipboard-list"></i> Order</button></div>
                        </div>
                    </div>
                </a>


<?php include 'includes-pages/footer.php'?>